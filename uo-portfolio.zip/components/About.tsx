export default function About() {
  return (
    <section
      id="about"
      className="max-w-7xl mx-auto px-8 py-32"
    >
      <div className="grid lg:grid-cols-2 gap-16 items-center">

        <div>
          <p className="uppercase tracking-[8px] text-gray-500 mb-5">
            Men haqimda
          </p>

          <h2 className="text-5xl font-bold leading-tight mb-8">
            Men nafaqat dizayn
            <br />
            balki natija yarataman.
          </h2>

          <p className="text-gray-400 leading-8 text-lg">
            Men Brand Dizayner, SMM Menejer va Mobilografman.
            Mening maqsadim — bizneslarga zamonaviy vizual
            identika yaratish va ularning ijtimoiy tarmoqlarda
            professional ko'rinishiga yordam berish.
          </p>

         <div className="grid grid-cols-3 gap-6 mt-20">


  <div className="
    rounded-3xl
    bg-gradient-to-br
    from-violet-500
    via-purple-600
    to-fuchsia-500
    p-6
    shadow-[0_0_40px_rgba(139,92,246,0.25)]
  ">

    <h3 className="text-4xl font-bold text-white">
      50+
    </h3>

    <p className="mt-2 text-white/80">
      Loyihalar
    </p>

  </div>



  <div className="
    rounded-3xl
    bg-gradient-to-br
    from-violet-500
    via-purple-600
    to-fuchsia-500
    p-6
    shadow-[0_0_40px_rgba(139,92,246,0.25)]
  ">

    <h3 className="text-4xl font-bold text-white">
      30+
    </h3>

    <p className="mt-2 text-white/80">
      Mijozlar
    </p>

  </div>



  <div className="
    rounded-3xl
    bg-gradient-to-br
    from-violet-500
    via-purple-600
    to-fuchsia-500
    p-6
    shadow-[0_0_40px_rgba(139,92,246,0.25)]
  ">

    <h3 className="text-4xl font-bold text-white">
      3+
    </h3>

    <p className="mt-2 text-white/80">
      Yil tajriba
    </p>

  </div>


</div>

        </div>

        <div>

          <img
            src="/me.jpg.png"
            alt="Ulugbek"
            className="rounded-[35px] border border-white/10"
          />

        </div>

      </div>
    </section>
  );
}